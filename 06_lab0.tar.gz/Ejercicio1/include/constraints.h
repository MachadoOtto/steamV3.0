/* Laboratorio Programacion IV - INCO/FING/UDELAR
 * Laboratorio 0 - Modulo de clase
 * Autores (por nombre):
 * 	Alexis Baladon 
 * 	Guillermo Toyos
 * 	Jorge Machado
 * 	Juan Jose Mangado
 * 	Mathias Ramilo
 */

/* Los siguientes valores son el valor maximo de jugadores, videojuegos y partidas (respectivamente) que soporta el sistema.
 */

#ifndef CONSTRAINTS
#define CONSTRAINTS

#define MAX_JUGADORES 100000
#define MAX_VIDEOJUEGOS 100000
#define MAX_PARTIDAS 100000

#endif


