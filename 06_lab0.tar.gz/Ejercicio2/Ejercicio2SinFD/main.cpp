#include <iostream>
#include "include/A.h"
#include "include/B.h"
#include "include/C.h"

int main() {
    claseA a;
    claseB b;
    claseC c;
    a.output();
    b.output();
    c.output();
    return 0;
}
