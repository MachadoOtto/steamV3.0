/* Laboratorio Programacion IV - INCO/FING/UDELAR
 * Laboratorio 0 - Modulo de clase
 * Autores (por nombre):
 * 	Alexis Baladon 
 * 	Guillermo Toyos
 * 	Jorge Machado
 * 	Juan Jose Mangado
 * 	Mathias Ramilo
 */

#ifndef TIPO_JUEGO
#define TIPO_JUEGO

// Enumeración con los Géneros disponibles para 'Videojuego' y 'DtVideojuego'.
enum class TipoJuego {Accion, Aventura, Deporte, Otro};

#endif
