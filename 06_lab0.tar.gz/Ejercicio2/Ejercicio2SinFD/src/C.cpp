#include "../include/C.h"

#include <iostream>

claseC::claseC() {
	this->a = NULL;
	this->b = NULL;
}

claseC::~claseC() {}

void claseC::output() {
    std::cout << c << ") La clase C funciona" << std::endl;
}


